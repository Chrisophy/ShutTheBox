# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import xbmcgui
import xbmc
import random
import xbmcaddon
import os
import re
import itertools # NEU: Für die CPU-Strategie

# --- HILFSVARIABLEN UND FUNKTIONEN ---

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo(u'path')
resources_path = os.path.join(addon_path, u'resources')

def get_spieler_anzahl_dialog():
    dialog = xbmcgui.Dialog()
    
    # NEU: Der Text wurde angepasst, um die CPU-Ergänzung zu berücksichtigen
    anzahl_optionen = [u"1 Spieler (mit CPU)", u"2 Spieler", u"3 Spieler", u"4 Spieler"]
    
    auswahl_index = dialog.select(u"Wähle die Anzahl der Spieler (1-4)", anzahl_optionen)
    
    
    if auswahl_index == -1:
        return 0
    else:
        # Bei Index 0 wird intern auf 2 Spieler (1 Mensch, 1 CPU) hochgesetzt
        # Ansonsten ist die Anzahl index + 1
        return auswahl_index + 1

def get_spieloption_dialog():
    dialog = xbmcgui.Dialog()
    
    optionen = [
        u"Standardspiel: Box schließen oder Punkte sammeln (Verlierer hat höchste Punktzahl)",
        u"Highscore-Spiel: Spiel endet, wenn ein Spieler 100 Strafpunkte erreicht",
        u"Bestätigen/Beenden-Spiel: 100-Strafpunkt-Regeln, aber vorzeitiges Beenden möglich"
    ]
    
    # 0 = Standardspiel, 1 = Highscore-Spiel, 2 = Bestätigen/Beenden-Spiel
    auswahl_index = dialog.select(u"Wähle die Spieloption", optionen)
    
    if auswahl_index == -1:
        return -1 # Abgebrochen
    else:
        return auswahl_index 

# --- SPIELLOGIK (ShutTheBoxGame) ---

class ShutTheBoxGame:
    def __init__(self, anzahl_spieler, spielmodus=0): 
        
        # NEU: CPU-Parameter werden erst nach Initialisierung gesetzt
        self.cpu_spieler_id = 0 
        self.ist_cpu_spiel_flag = False
        
        self.spieler_anzahl = anzahl_spieler
        self.spieler_zustaende = {i: [1, 2, 3, 4, 5, 6, 7, 8, 9] for i in range(1, anzahl_spieler + 1)}
        self.aktueller_spieler = 1
        
        self.punkte = {i: 0 for i in range(1, anzahl_spieler + 1)} 
        
        self.runden_gespielt = {i: 1 for i in range(1, anzahl_spieler + 1)}
        
        self.ergebnisse = {} # Endgültige Ergebnisse
        self.spielmodus = spielmodus 

        self.wuerfel_1 = 0
        self.wuerfel_2 = 0
        self.summe = 0

    # NEU: Methoden für CPU-Erkennung
    def set_cpu_spiel_flag(self, flag):
         """Setzt das Flag, ob ein CPU-Spiel vorliegt und setzt die CPU-ID."""
         self.ist_cpu_spiel_flag = flag
         if flag and self.spieler_anzahl == 2:
             self.cpu_spieler_id = 2 # Spieler 2 ist die CPU

    def ist_aktueller_spieler_cpu(self):
         return self.aktueller_spieler == self.cpu_spieler_id

    def get_aktuelle_zahlen(self):
        return self.spieler_zustaende.get(self.aktueller_spieler, [])

    def wuerfeln(self):
        self.wuerfel_1 = random.randint(1, 6)
        self.wuerfel_2 = random.randint(1, 6)
        self.summe = self.wuerfel_1 + self.wuerfel_2
            
        xbmc.log(f"[ShutTheBox STATE] Spieler {self.aktueller_spieler}. Würfel: {self.wuerfel_1}, {self.wuerfel_2}. Summe: {self.summe}. Übrig: {self.get_aktuelle_zahlen()}", xbmc.LOGINFO)

    def ist_gueltiger_zug(self, gewaehlte_zahlen):
        if not gewaehlte_zahlen or sum(gewaehlte_zahlen) != self.summe:
            return False
            
        aktuelle_zahlen = self.get_aktuelle_zahlen()
        for zahl in gewaehlte_zahlen:
            if zahl not in aktuelle_zahlen:
                return False 
        return True
    
    def _finde_kombination_dp(self, ziel_summe, verfuegbare_zahlen):
        if ziel_summe < 0:
            return False
            
        dp = [False] * (ziel_summe + 1)
        dp[0] = True 

        for zahl in verfuegbare_zahlen:
            for s in range(ziel_summe, zahl - 1, -1):
                if dp[s - zahl]:
                    dp[s] = True
        
        return dp[ziel_summe]

    def ist_zug_moeglich(self):
        aktuelle_zahlen = sorted(self.get_aktuelle_zahlen())
        
        if not aktuelle_zahlen:
            return False
            
        if sum(aktuelle_zahlen) < self.summe:
            return False

        if min(aktuelle_zahlen) > self.summe:
             return False

        return self._finde_kombination_dp(self.summe, aktuelle_zahlen)

    # NEU: CPU-Strategie
    def finde_beste_kombination(self):
        """
        CPU-Strategie: Versucht die längste Kombination zu finden.
        Längste Kombination = höchste Wahrscheinlichkeit, die Box zu schließen.
        """
        ziel_summe = self.summe
        verfuegbare_zahlen = sorted(self.get_aktuelle_zahlen(), reverse=False) # Aufsteigend sortieren
        
        # Beginne mit der längsten möglichen Kombination absteigend
        for laenge in range(len(verfuegbare_zahlen), 0, -1):
            
            # Wähle die Kombinationen der aktuellen Länge
            # Kombinationen werden automatisch lexikografisch/numerisch sortiert
            for kombination in itertools.combinations(verfuegbare_zahlen, laenge):
                
                if sum(kombination) == ziel_summe:
                    # Die längste zuerst gefundene Kombination ist die beste
                    return list(kombination)
        
        return []

    def klappe_zahl_um(self, zahl):
        aktuelle_zahlen = self.get_aktuelle_zahlen()
        if zahl in aktuelle_zahlen:
            aktuelle_zahlen.remove(zahl)
            return True
        return False
        
    def set_zustaende_fuer_neuen_zug(self):
        """Setzt die Zahlen im Highscore-Modus und Bestätigen/Beenden-Modus (1 & 2) zurück."""
        # Modus 1 (Highscore) und Modus 2 (Bestätigen/Beenden) starten jede Runde mit 1-9
        if self.spielmodus in (1, 2):
            self.spieler_zustaende[self.aktueller_spieler] = [1, 2, 3, 4, 5, 6, 7, 8, 9]

    def beende_runde(self):
        
        hinzuzufuegende_punkte = sum(self.get_aktuelle_zahlen())

        # KORREKTUR: Die Runde des AKTUELLEN Spielers ist beendet. Zähler erhöhen.
        # Dies geschieht jetzt IMMER, unabhängig davon, ob gewonnen (Box geschlossen) oder verloren.
        self.runden_gespielt[self.aktueller_spieler] += 1 

        if self.spielmodus == 0:
            # Standardmodus: Spieler scheidet aus (Punkte sind die restlichen Ziffernsumme)
            if self.aktueller_spieler not in self.ergebnisse:
                self.ergebnisse[self.aktueller_spieler] = hinzuzufuegende_punkte
                xbmc.log(f"[ShutTheBox STATE] Spieler {self.aktueller_spieler} beendet Spiel mit {self.ergebnisse[self.aktueller_spieler]} Punkten (Standard).", xbmc.LOGINFO)
            
            # Endbedingung für Modus 0: Alle Spieler ausgeschieden
            if len(self.ergebnisse) == self.spieler_anzahl:
                return False # Spiel beenden (Game Over)
            
        elif self.spielmodus in (1, 2):
            # Modus 1 (Highscore) und Modus 2 (Bestätigen/Beenden)
            # Punkte werden akkumuliert (positiv, da es Strafpunkte sind)
            self.punkte[self.aktueller_spieler] += hinzuzufuegende_punkte
            xbmc.log(f"[ShutTheBox STATE] Spieler {self.aktueller_spieler} verliert Runde. Neue Punkte: {self.punkte[self.aktueller_spieler]} (Modus 1/2).", xbmc.LOGINFO)
            
            # Endbedingung für Modus 1 und 2: Punkte 100 oder mehr erreicht
            if self.punkte[self.aktueller_spieler] >= 100:
                # Trage alle Punktstände in die Endtabelle ein
                for spieler_id, punkte in self.punkte.items():
                    if spieler_id not in self.ergebnisse:
                         self.ergebnisse[spieler_id] = punkte
                return False # Spiel beenden (Game Over)

        # 2. Nächsten Spieler ermitteln
        start_spieler = self.aktueller_spieler
        
        while True:
            naechster_spieler = (self.aktueller_spieler % self.spieler_anzahl) + 1 
            
            # Im Modus 0: Nur zu Spielern wechseln, die noch nicht ausgeschieden sind
            if self.spielmodus == 0:
                 if naechster_spieler not in self.ergebnisse:
                    self.aktueller_spieler = naechster_spieler
                    # Runden-Zähler wurde bereits oben inkrementiert
                    return True # Nächste Runde beginnen
            
            # Im Modus 1 und 2: Es geht immer reihum, da keiner ausscheidet, bis die Endbedingung erreicht ist
            elif self.spielmodus in (1, 2):
                 self.aktueller_spieler = naechster_spieler
                 # Runden-Zähler wurde bereits oben inkrementiert
                 return True # Nächste Runde beginnen
            
            # Standardmodus: Prüfen, ob alle ausgeschieden sind
            self.aktueller_spieler = naechster_spieler
            
            if self.aktueller_spieler == start_spieler and self.spielmodus == 0:
                return False # Spiel beendet, alle sind ausgeschieden

    def get_highscore_tabelle(self):
        
        # Für Modus 1 und 2: Wenn das Spiel abgebrochen wird, müssen die aktuellen Punkte als Endergebnis dienen
        if self.spielmodus in (1, 2) and not self.ergebnisse:
             for spieler_id, punkte in self.punkte.items():
                 self.ergebnisse[spieler_id] = punkte
                     
        # Alle Modi: Niedrigste Punktzahl gewinnt (da es Strafpunkte sind)
        return sorted(self.ergebnisse.items(), key=lambda item: item[1])


# --- GUI (ShutTheBoxGUI) ---

class ShutTheBoxGUI(xbmcgui.WindowDialog):
    neustart_angefordert = False
    gewaehlte_spieloption = 0 # 0=Standard, 1=Highscore, 2=Bestätigen/Beenden

    def __init__(self):
        super(ShutTheBoxGUI, self).__init__()
        
        self.ist_cpu_spiel_flag = False # NEU: Für die Instanz
        
        if not ShutTheBoxGUI.neustart_angefordert:
             self.spieler_anzahl = get_spieler_anzahl_dialog()
             if self.spieler_anzahl == 0:
                 self.game = None
                 return
             
             # NEU: Falls 1 Spieler gewählt (Index 0), fügen wir einen zweiten (CPU) hinzu
             if self.spieler_anzahl == 1:
                 self.ist_cpu_spiel_flag = True
                 self.spieler_anzahl = 2 # Spiel wird mit 2 Spielern gestartet
                 xbmcgui.Dialog().notification(u"Zweiter Spieler (CPU) hinzugefügt!", xbmcgui.NOTIFICATION_INFO, sound=False)
             
             # Spieloption abfragen
             spielmodus_auswahl = get_spieloption_dialog()
             if spielmodus_auswahl == -1:
                 self.game = None
                 return
             ShutTheBoxGUI.gewaehlte_spieloption = spielmodus_auswahl
        
        if self.spieler_anzahl == 0: # Überprüfung nach Dialogen
            self.game = None
            return

        # Spielmodus an das Game-Objekt übergeben
        self.game = ShutTheBoxGame(self.spieler_anzahl, ShutTheBoxGUI.gewaehlte_spieloption)
        # NEU: Das Flag für das CPU-Spiel im Game-Objekt setzen
        if self.ist_cpu_spiel_flag:
             self.game.set_cpu_spiel_flag(self.ist_cpu_spiel_flag)
        
        self.gewaehlte_zahlen_temp = []
        self.ungueltige_auswahl = [] 
        self.muss_wuerfeln = True 
        
        self.wuerfel_bilder = [
            os.path.join(resources_path, u'wuerfel_{}.png'.format(i)) for i in range(1, 7)
        ]
        
        
        ZENTRIERTE_AUSRICHTUNG = 0x00000002 
        LINKS_VERSCHIEBUNG = 0 
        MITTE_VERSCHIEBUNG_OFFSET = 400 
        LINKS_OBEN_X = 50 
        LINKS_OBEN_BREITE = 400
        WÜRFEL_GRÖSSE = 150 
        WÜRFEL_ABSTAND = 40
        WÜRFEL_Y = 150 
        GESAMT_WÜRFEL_BREITE = (WÜRFEL_GRÖSSE * 2) + WÜRFEL_ABSTAND
        START_X_WÜRFEL = (1920 // 2 - GESAMT_WÜRFEL_BREITE // 2) - MITTE_VERSCHIEBUNG_OFFSET
        LABEL_BREITE = GESAMT_WÜRFEL_BREITE 
        LABEL_HÖHE = 60
        LABEL_FONT = u"font40" 
        ZAHL_BREITE = 80    
        ZAHL_HÖHE = 80      
        ZAHL_ABSTAND = 10   
        NUM_ZAHLEN = 9
        GESAMT_ZAHLEN_BREITE = (NUM_ZAHLEN * ZAHL_BREITE) + ((NUM_ZAHLEN - 1) * ZAHL_ABSTAND) 
        START_X_ZAHLEN = (1920 // 2 - GESAMT_ZAHLEN_BREITE // 2) - MITTE_VERSCHIEBUNG_OFFSET
        ZAHLEN_Y = 400 
        BUTTON_BREITE = 350 
        BUTTON_HÖHE = 100   
        BUTTON_ABSTAND = 60 
        BUTTON_FONT = u"font60" 
        ZAHLEN_FONT = u"font45" 
        GESAMT_AKTION_BUTTONS_BREITE = (BUTTON_BREITE * 2) + BUTTON_ABSTAND
        START_X_AKTION_BUTTONS = (1920 // 2 - GESAMT_AKTION_BUTTONS_BREITE // 2) - MITTE_VERSCHIEBUNG_OFFSET
        AKTION_BUTTONS_Y = ZAHLEN_Y + ZAHL_HÖHE + 80 
        self.background_image = xbmcgui.ControlImage(0, 0, 1920, 1080, os.path.join(resources_path, u'hintergrund.jpg'))
        self.addControl(self.background_image)
        self.wuerfel_control_1 = xbmcgui.ControlImage(START_X_WÜRFEL, WÜRFEL_Y, WÜRFEL_GRÖSSE, WÜRFEL_GRÖSSE, self.wuerfel_bilder[0])
        self.addControl(self.wuerfel_control_1)
        self.wuerfel_control_2 = xbmcgui.ControlImage(START_X_WÜRFEL + WÜRFEL_GRÖSSE + WÜRFEL_ABSTAND, WÜRFEL_Y, WÜRFEL_GRÖSSE, WÜRFEL_GRÖSSE, self.wuerfel_bilder[0])
        self.addControl(self.wuerfel_control_2)
        self.spieler_label = xbmcgui.ControlLabel(
            LINKS_OBEN_X, 
            30, 
            LINKS_OBEN_BREITE, 
            LABEL_HÖHE, 
            u"", 
            font=u"font50", 
            alignment=0 
        )
        self.addControl(self.spieler_label)
        self.summe_label = xbmcgui.ControlLabel(
            START_X_WÜRFEL, 
            WÜRFEL_Y - LABEL_HÖHE + 20, 
            LABEL_BREITE, 
            LABEL_HÖHE, 
            u"Summe: 0", 
            font=LABEL_FONT, 
            alignment=ZENTRIERTE_AUSRICHTUNG 
        )
        self.addControl(self.summe_label)
        X_PUNKTE_LABEL = LINKS_OBEN_X 
        Y_PUNKTE_LABEL = 80 
        PUNKTE_BREITE = LINKS_OBEN_BREITE 
        PUNKTE_HÖHE = 50 
        PUNKTE_FONT = u"font40" 
        self.gesamtpunkte_label = xbmcgui.ControlLabel(
            X_PUNKTE_LABEL, Y_PUNKTE_LABEL, PUNKTE_BREITE, PUNKTE_HÖHE, u"Punkte: 45", font=PUNKTE_FONT
        )
        self.addControl(self.gesamtpunkte_label)
        if self.game.spielmodus in (1, 2):
            Y_HIGHSCORE_LABEL = Y_PUNKTE_LABEL + PUNKTE_HÖHE
            self.highscore_label = xbmcgui.ControlLabel(
                 LINKS_OBEN_X, 
                 Y_HIGHSCORE_LABEL, 
                 LINKS_OBEN_BREITE, LABEL_HÖHE, u"", font=LABEL_FONT
            )
            self.addControl(self.highscore_label)
            Y_RUNDEN_LABEL = Y_HIGHSCORE_LABEL + PUNKTE_HÖHE
        else:
            self.highscore_label = None
            Y_RUNDEN_LABEL = Y_PUNKTE_LABEL + PUNKTE_HÖHE
        self.runden_label = xbmcgui.ControlLabel(
            LINKS_OBEN_X, 
            Y_RUNDEN_LABEL, 
            LINKS_OBEN_BREITE, PUNKTE_HÖHE, u"", font=PUNKTE_FONT
        )
        self.addControl(self.runden_label)
        self.zahlen_controls = []
        x_position = START_X_ZAHLEN
        for i in range(1, 10):
            zahl_button = xbmcgui.ControlButton(x_position, ZAHLEN_Y, ZAHL_BREITE, ZAHL_HÖHE, str(i), font=ZAHLEN_FONT, alignment=ZENTRIERTE_AUSRICHTUNG) 
            self.addControl(zahl_button)
            self.zahlen_controls.append(zahl_button)
            x_position += ZAHL_BREITE + ZAHL_ABSTAND 
        self.wuerfeln_button = xbmcgui.ControlButton(START_X_AKTION_BUTTONS, AKTION_BUTTONS_Y, BUTTON_BREITE, BUTTON_HÖHE, u"Würfeln", font=BUTTON_FONT, alignment=ZENTRIERTE_AUSRICHTUNG)
        self.addControl(self.wuerfeln_button)
        initial_label_bestaetigen = u"Zug bestätigen"
        if self.game.spielmodus == 2:
             initial_label_bestaetigen = u"Bestätigen/Beenden" 
        self.zug_bestaetigen_button = xbmcgui.ControlButton(START_X_AKTION_BUTTONS + BUTTON_BREITE + BUTTON_ABSTAND, AKTION_BUTTONS_Y, BUTTON_BREITE, BUTTON_HÖHE, initial_label_bestaetigen, font=BUTTON_FONT, alignment=ZENTRIERTE_AUSRICHTUNG)
        self.addControl(self.zug_bestaetigen_button)
        self.zug_bestaetigen_button.setEnabled(False) 
        NUM_ZAHLEN = 9
        for i, control in enumerate(self.zahlen_controls):
            links = self.zahlen_controls[i - 1] if i > 0 else self.zahlen_controls[NUM_ZAHLEN - 1]
            rechts = self.zahlen_controls[i + 1] if i < NUM_ZAHLEN - 1 else self.zahlen_controls[0]
            oben = self.wuerfeln_button 
            unten = self.zug_bestaetigen_button 
            control.setNavigation(
                left=links, 
                right=rechts, 
                up=oben, 
                down=unten
            )
        self.wuerfeln_button.setNavigation(
            left=self.zug_bestaetigen_button,
            right=self.zug_bestaetigen_button,
            up=self.zahlen_controls[0],      
            down=self.zahlen_controls[0]
        )
        self.zug_bestaetigen_button.setNavigation(
            left=self.wuerfeln_button,
            right=self.wuerfeln_button,
            up=self.zahlen_controls[NUM_ZAHLEN - 1], 
            down=self.zahlen_controls[NUM_ZAHLEN - 1]
        )
        self.setFocus(self.wuerfeln_button)
        
        self.update_spieler_ui(is_new_round=True)
        # NEU: Prüfen, ob die CPU als erster Spieler dran ist
        self._check_and_start_cpu_turn()
    
    def set_wuerfel_sichtbarkeit(self, visible):
        self.wuerfel_control_1.setVisible(visible)
        self.wuerfel_control_2.setVisible(visible)
        self.summe_label.setVisible(visible)
        
    def onAction(self, action):
        # NEU: Eingaben ignorieren, wenn CPU am Zug
        if self.game.ist_aktueller_spieler_cpu():
             return

        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PARENT_DIR):
            self.close()
            
        elif action.getId() == xbmcgui.ACTION_SELECT_ITEM:
            focused_control = self.getFocus()
            
            if focused_control in [self.wuerfeln_button, self.zug_bestaetigen_button]:
                self.onControl(focused_control)
            
            elif focused_control in self.zahlen_controls:
                label = focused_control.getLabel()
                try:
                    # Der Regex entfernt Farbcodes wie [COLOR FF00FF00]
                    zahl_str = re.sub(r'\[.*?\]', '', label) 
                    zahl = int(zahl_str)
                    
                    if not self.muss_wuerfeln: 
                        self.zahl_auswaehlen(zahl)
                        
                except (ValueError, IndexError):
                    pass
        
    def onControl(self, control):
        # NEU: Eingaben ignorieren, wenn CPU am Zug
        if self.game.ist_aktueller_spieler_cpu():
             return

        label = control.getLabel()

        if label.startswith(u"Würfeln"): 
            if self.muss_wuerfeln:
                self.wuerfeln_und_anzeigen()
            else:
                xbmcgui.Dialog().notification("Bestätige deinen Zug!", xbmcgui.NOTIFICATION_INFO, sound=False)
        
        elif label in (u"Zug bestätigen", u"Bestätigen/Beenden"):
            
            if not self.muss_wuerfeln:
                self.bestaetige_zug()
            else:
                 xbmcgui.Dialog().notification("Du musst zuerst würfeln!", xbmcgui.NOTIFICATION_INFO, sound=False)

        else:
            try:
                zahl_str = re.sub(r'\[.*?\]', '', label) 
                zahl = int(zahl_str)
                if not self.muss_wuerfeln: 
                    self.zahl_auswaehlen(zahl)
            except (ValueError, IndexError):
                pass
        
    def _wechsel_spieler_und_starte_neue_runde(self):
        """Führt den Spielerwechsel und die UI-Vorbereitung für die nächste Runde durch."""
        if not self.game.beende_runde():
            self.zeige_highscore()
            return
        
        self.gewaehlte_zahlen_temp = []
        self.ungueltige_auswahl = [] # Fehlerzustand bereinigen
        self.muss_wuerfeln = True
        self.summe_label.setLabel(u"Summe: 0")
        self.set_wuerfel_sichtbarkeit(False)
        self.update_spieler_ui(is_new_round=True)
        
        # NEU: Nach Spielerwechsel CPU-Zug prüfen und ggf. starten
        self._check_and_start_cpu_turn() 
        
    # NEU: CPU-Ablauf-Funktionen
    def _check_and_start_cpu_turn(self):
        """Prüft, ob der aktuelle Spieler die CPU ist, und startet deren Zug."""
        if self.game and self.game.ist_aktueller_spieler_cpu():
            xbmc.sleep(1000) # Kurze Pause, damit der Spieler sieht, dass der Zug wechselt
            self.cpu_zug_ablauf()

    # KORREKTUR DER LOGIK HIER
    def cpu_zug_ablauf(self):
        """Führt den kompletten Zug der CPU aus, bis die Runde beendet ist."""
        
        # UI für menschliche Interaktion deaktivieren
        self.wuerfeln_button.setEnabled(False)
        self.zug_bestaetigen_button.setEnabled(False)
        for control in self.zahlen_controls:
             control.setEnabled(False)
        
        # Sicherstellen, dass die CPU würfeln muss (Startzustand)
        self.muss_wuerfeln = True 

        # Schleife, die so lange läuft, bis die Runde beendet ist
        while True:
            
            if self.muss_wuerfeln:
                # 1. Würfeln
                xbmcgui.Dialog().notification(u"CPU würfelt...", xbmcgui.NOTIFICATION_INFO, sound=False)
                xbmc.sleep(1000) 
                # Führt Würfeln aus und prüft, ob ein Zug möglich ist.
                # WENN kein Zug möglich, wird die Runde beendet und der Spieler gewechselt (self.muss_wuerfeln bleibt True).
                self.wuerfeln_und_anzeigen(is_cpu=True) 

                if self.muss_wuerfeln:
                    # Wenn 'wuerfeln_und_anzeigen' self.muss_wuerfeln auf True belassen hat,
                    # bedeutet dies, dass die Runde beendet wurde (kein Zug möglich) 
                    # und der Spieler bereits gewechselt ist.
                    break 
                
                # Nach dem Würfeln ist self.muss_wuerfeln jetzt False (Zug muss gemacht werden).
                xbmc.sleep(1000)

            # 2. Zug des CPU-Spielers: Versuche, einen Zug zu finden und zu bestätigen
            
            self.gewaehlte_zahlen_temp = self.game.finde_beste_kombination()
            
            if self.gewaehlte_zahlen_temp:
                 
                 # Simuliere die Auswahl in der UI
                 self.update_zahlen_ui()
                 xbmc.sleep(1000)
                 
                 xbmcgui.Dialog().notification(u"CPU schließt Zahlen: {}".format(self.gewaehlte_zahlen_temp), xbmcgui.NOTIFICATION_INFO, sound=False)
                 
                 # Bestätigen des Zuges: 
                 # Setzt muss_wuerfeln=True (erneut würfeln) ODER 
                 # ruft _wechsel_spieler_und_starte_neue_runde() auf (Box geschlossen).
                 self.bestaetige_zug(is_cpu=True) 
                 
                 # Wenn die Runde durch _wechsel_spieler_und_starte_neue_runde beendet wurde, 
                 # bricht die Schleife ab.
                 if self.game.aktueller_spieler != self.game.cpu_spieler_id:
                     break
                 
            else:
                 # Kein weiterer Zug gefunden (oder CPU entscheidet, die Runde zu beenden)
                 xbmcgui.Dialog().notification(u"CPU beendet die Runde.", xbmcgui.NOTIFICATION_INFO, sound=False)
                 self.gewaehlte_zahlen_temp = [] # Leere Auswahl für Beenden-Modus 2
                 
                 # Beendet die Runde (entweder durch "Kein Zug möglich" oder Modus 2)
                 self.bestaetige_zug(is_cpu=True) 
                 break

    def update_spieler_ui(self, is_new_round=False):
        runden_aktuell = self.game.runden_gespielt[self.game.aktueller_spieler]
        
        # NEU: Label-Anpassung, falls CPU am Zug
        spieler_label_text = u"Spieler {}".format(self.game.aktueller_spieler)
        if self.game.ist_aktueller_spieler_cpu():
             spieler_label_text += u" (CPU)"
             
        self.spieler_label.setLabel(u"[COLOR FF00FF00]{} ist dran (Runde {})[/COLOR]".format(spieler_label_text, runden_aktuell))
        
        if self.game.spielmodus in (1, 2) and self.highscore_label:
            punkte = self.game.punkte[self.game.aktueller_spieler]
            farbe = u"FFFF0000" if punkte >= 90 else (u"FFFFA500" if punkte >= 70 else u"FFFFFFFF")
            self.highscore_label.setLabel(u"[COLOR {}]Strafpunkte: {}[/COLOR]".format(farbe, punkte)) 

        self.runden_label.setLabel(u"Abgeschlossene Runden: {}".format(runden_aktuell - 1))
            
        if self.game.spielmodus in (1, 2) and is_new_round:
            self.game.set_zustaende_fuer_neuen_zug()
            
        # NEU: UI-Aktivierung nur für menschliche Spieler
        is_human_player = not self.game.ist_aktueller_spieler_cpu()
        
        if self.muss_wuerfeln:
            self.wuerfeln_button.setEnabled(is_human_player)
            self.zug_bestaetigen_button.setEnabled(False)
            if is_human_player:
                self.setFocus(self.wuerfeln_button)
            self.set_wuerfel_sichtbarkeit(False)
            self.wuerfeln_button.setLabel(u"Würfeln")
            
        else:
             self.wuerfeln_button.setEnabled(False)
             self.zug_bestaetigen_button.setEnabled(is_human_player) 
             self.wuerfeln_button.setLabel(u"Würfeln") 
             
        self.update_zahlen_ui()

    def zeige_highscore(self):
        tabelle = self.game.get_highscore_tabelle()
        
        if self.game.spielmodus == 0:
             titel = u"Highscore - Standardspiel"
             spiel_ende_text = u"Alle Spieler sind ausgeschieden. Ergebnis:"
        else: 
             titel = u"Highscore - 100 Strafpunkte-Spiel"
             verlierer_id = tabelle[-1][0] 
             spiel_ende_text = u"Spiel beendet! Spieler {} hat 100 oder mehr Strafpunkte erreicht.".format(verlierer_id)
        
        nachrichten = []
        
        for i, (spieler_nr, punkte) in enumerate(tabelle):
             platz = i + 1
             runden = self.game.runden_gespielt.get(spieler_nr, 1) - 1 
             
             spieler_name = u"Spieler " + str(spieler_nr)
             if self.game.cpu_spieler_id == spieler_nr:
                 spieler_name += u" (CPU)"
             
             text_zeile = u"[{}. Platz] {} - {} Strafpunkte ({} Runden)".format(platz, spieler_name, punkte, runden)
             nachrichten.append(text_zeile)

        nachricht = spiel_ende_text + u"\n\n" + u"\n".join(nachrichten)

        xbmcgui.Dialog().ok(titel, nachricht)

        neustart_anfrage = xbmcgui.Dialog().yesno(
            u"Spiel beendet",
            u"Möchtest du ein neues Spiel starten?",
            yeslabel=u"Ja, neu starten",
            nolabel=u"Nein, beenden"
        )

        if neustart_anfrage:
            ShutTheBoxGUI.neustart_angefordert = True
            self.close() 
        else:
            ShutTheBoxGUI.neustart_angefordert = False
            self.close()
            
    # NEU: is_cpu Parameter hinzugefügt, um zu verhindern, dass die CPU-Runde blockiert
    def wuerfeln_und_anzeigen(self, is_cpu=False):
        
        if not is_cpu and self.game.ist_aktueller_spieler_cpu():
             return

        self.gewaehlte_zahlen_temp = []
        self.ungueltige_auswahl = [] 
        self.muss_wuerfeln = False
        self.wuerfeln_button.setEnabled(False)
        self.zug_bestaetigen_button.setEnabled(not self.game.ist_aktueller_spieler_cpu())

        self.game.wuerfeln()
        
        self.set_wuerfel_sichtbarkeit(True)
        self.wuerfel_control_1.setImage(self.wuerfel_bilder[self.game.wuerfel_1 - 1])
        self.wuerfel_control_2.setImage(self.wuerfel_bilder[self.game.wuerfel_2 - 1])
        self.summe_label.setLabel(u"Summe: {}".format(self.game.summe))
        
        self.update_zahlen_ui()

        fokus_gesetzt = False
        if not self.game.ist_aktueller_spieler_cpu():
            for control in self.zahlen_controls:
                label = control.getLabel()
                try:
                    zahl = int(re.sub(r'\[.*?\]', '', label))
                except ValueError:
                    continue 
                
                if zahl in self.game.get_aktuelle_zahlen():
                    self.setFocus(control)
                    fokus_gesetzt = True
                    break
        
        if not fokus_gesetzt and not self.game.ist_aktueller_spieler_cpu():
             self.setFocus(self.zug_bestaetigen_button)
        
        if not self.game.ist_zug_moeglich():
            # Kein Zug möglich -> Runde beenden
            self.wuerfeln_button.setEnabled(False)
            self.zug_bestaetigen_button.setEnabled(False)
            
            verlorene_punkte = sum(self.game.get_aktuelle_zahlen())
            
            # Die Benachrichtigung kommt nur für menschliche Spieler (CPU macht den Zug im cpu_zug_ablauf)
            if not self.game.ist_aktueller_spieler_cpu():
                xbmcgui.Dialog().notification(
                    "Kein Zug möglich!", 
                    xbmcgui.NOTIFICATION_INFO, sound=False
                )
            
            # Die Runde beenden (Spielerwechsel)
            self._wechsel_spieler_und_starte_neue_runde()
            
            # WICHTIG: muss_wuerfeln = True setzen, da die Runde hier beendet wurde
            self.muss_wuerfeln = True

    def zahl_auswaehlen(self, zahl):
        # NEU: Eingaben ignorieren, wenn CPU am Zug
        if self.game.ist_aktueller_spieler_cpu():
             return

        if zahl in self.game.get_aktuelle_zahlen():
            if zahl not in self.gewaehlte_zahlen_temp:
                if sum(self.gewaehlte_zahlen_temp) + zahl <= self.game.summe:
                    self.gewaehlte_zahlen_temp.append(zahl)
                    self.ungueltige_auswahl = [] 
                else:
                    if not self.gewaehlte_zahlen_temp:
                        self.ungueltige_auswahl = [zahl] 
                    pass 
            else:
                self.gewaehlte_zahlen_temp.remove(zahl)
                self.ungueltige_auswahl = [] 
            
            self.update_zahlen_ui()

    # NEU: is_cpu Parameter hinzugefügt, um Dialoge für die CPU zu unterdrücken
    def bestaetige_zug(self, is_cpu=False):
        
        # 1. PRÜFE AUF UNGÜLTIGE EINZELZAHLEN-AUSWAHL
        if self.ungueltige_auswahl:
            fehler_zahl = self.ungueltige_auswahl[0]
            fehlermeldung = u"Ungültiger Zug! Die gewählte Zahl {} ist größer als die Würfelsumme {}.".format(fehler_zahl, self.game.summe)
            
            if not is_cpu:
                 self.zug_bestaetigen_button.setEnabled(False) 
                 xbmcgui.Dialog().ok(u"Fehler", fehlermeldung)
                 self.zug_bestaetigen_button.setEnabled(True) 
                 self.setFocus(self.zug_bestaetigen_button)
            
            self.ungueltige_auswahl = [] 
            self.update_zahlen_ui()
            return 
            
        # 2. PRÜFE AUF GÜLTIGEN ZUG (Zahlen gewählt UND Summe korrekt)
        if self.game.ist_gueltiger_zug(self.gewaehlte_zahlen_temp):
            for zahl in self.gewaehlte_zahlen_temp:
                self.game.klappe_zahl_um(zahl)
            
            self.gewaehlte_zahlen_temp = []
            
            if not self.game.get_aktuelle_zahlen():
                # BOX GESCHLOSSEN - RUNDENENDE
                if not is_cpu:
                    xbmcgui.Dialog().notification("Box geschlossen!", xbmcgui.NOTIFICATION_INFO, sound=False)
                self._wechsel_spieler_und_starte_neue_runde()
                
            else:
                # ERFOLGREICHER ZUG - WEITER WÜRFELN
                if not is_cpu:
                    xbmcgui.Dialog().notification("Erneut würfeln!", xbmcgui.NOTIFICATION_INFO, sound=False)

                self.muss_wuerfeln = True 
                self.summe_label.setLabel(u"Summe: 0")
                self.set_wuerfel_sichtbarkeit(False)
                self.update_spieler_ui()
                if not is_cpu:
                    self.setFocus(self.wuerfeln_button) 
                
        # 3. PRÜFE AUF UNGÜLTIGEN ZUG (Zahlen gewählt, aber Summe falsch)
        elif len(self.gewaehlte_zahlen_temp) > 0 and sum(self.gewaehlte_zahlen_temp) != self.game.summe:
            fehlermeldung = u"Ungültiger Zug! Die Summe der gewählten Zahlen muss {} ergeben.".format(self.game.summe)
                 
            if not is_cpu:
                 self.zug_bestaetigen_button.setEnabled(False) 
                 xbmcgui.Dialog().ok(u"Fehler", fehlermeldung)
                 self.zug_bestaetigen_button.setEnabled(True) 
                 self.setFocus(self.zug_bestaetigen_button)
            
            self.gewaehlte_zahlen_temp = []
            self.update_zahlen_ui()
            
        # 4. PRÜFE AUF VORZEITIGES BEENDEN (MODUS 2 UND KEINE ZAHLEN GEWÄHLT)
        elif self.game.spielmodus == 2 and not self.gewaehlte_zahlen_temp:
             # Dies ist der beabsichtigte Abbruch der Runde im Modus 2.
             
             if not is_cpu: # Dialog nur für menschliche Spieler
                 if self.game.ist_zug_moeglich():
                     xbmcgui.Dialog().notification(
                         "Runde vorzeitig beendet", 
                         xbmcgui.NOTIFICATION_INFO, sound=False
                     )
                 else:
                     xbmcgui.Dialog().notification(
                         "Kein Zug möglich", 
                         xbmcgui.NOTIFICATION_INFO, sound=False
                     )
                     
             self._wechsel_spieler_und_starte_neue_runde()
             
        # 5. Fallback (Keine Zahlen gewählt, nicht Modus 2)
        else:
             if not is_cpu:
                xbmcgui.Dialog().ok(u"Fehler", u"Aktion nicht zugeordnet oder ungültiger Zustand.")
                self.gewaehlte_zahlen_temp = []
                self.ungueltige_auswahl = []
                self.update_zahlen_ui()
                self.setFocus(self.zug_bestaetigen_button)


    def update_zahlen_ui(self):
        aktuelle_zahlen = self.game.get_aktuelle_zahlen()
        
        gesamtpunkte = sum(aktuelle_zahlen)
        punkte_text = u"Gesamtpunkte: {}".format(gesamtpunkte)
        
        if gesamtpunkte == 0:
            farbcode = u"FF00FF00" 
        elif gesamtpunkte < 10:
             farbcode = u"FFFFFF00" 
        else:
             farbcode = u"FFFFFFFF" 

        self.gesamtpunkte_label.setLabel(u"[COLOR {}]{}[/COLOR]".format(farbcode, punkte_text))
        
        # NEU: Steuerung ist nur für den menschlichen Spieler aktivierbar
        is_human_player = not self.game.ist_aktueller_spieler_cpu()
        
        for i, control in enumerate(self.zahlen_controls):
            zahl = i + 1
            
            if zahl not in aktuelle_zahlen:
                control.setVisible(False) 
                control.setEnabled(False) 
            else:
                control.setVisible(True)
                
                # Zahlen sind nur für den menschlichen Spieler wählbar
                control.setEnabled(is_human_player and not self.muss_wuerfeln) 
                     
                if zahl in self.gewaehlte_zahlen_temp:
                    control.setLabel(u"[COLOR FF00FF00]{}[/COLOR]".format(zahl))
                elif zahl in self.ungueltige_auswahl:
                    control.setLabel(u"[COLOR FFFF0000]{}[/COLOR]".format(zahl))
                else:
                    control.setLabel(str(zahl))
                

if __name__ == '__main__':
    ShutTheBoxGUI.neustart_angefordert = False
    
    while True:
        fenster = ShutTheBoxGUI()
        
        if fenster.game is not None:
            fenster.doModal()
            del fenster
            
            if not ShutTheBoxGUI.neustart_angefordert:
                break
            
            ShutTheBoxGUI.neustart_angefordert = False
        else:
            break
